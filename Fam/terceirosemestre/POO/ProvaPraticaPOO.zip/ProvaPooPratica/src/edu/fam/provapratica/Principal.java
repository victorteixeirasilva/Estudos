package edu.fam.provapratica;
/***
 * 
 * @author Victor Teixeira Silva Ra:00342509 / Danilo Sampaio Fonseca Ra: 00341537
 * @version 1.0
 * 
 *
 */

public class Principal {

	public static void main(String[] args) {
		Calculadora calculadora = new Calculadora();
		
		calculadora.menuCalculadora();

	}
		

}
