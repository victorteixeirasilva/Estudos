package edu.fam.provapratica;

import java.util.Scanner;

public class Calculadora {
	private Scanner entrada = new Scanner(System.in);
	private Double numeroExpoente;
	private Double numeroBase;
	private Double numeroFatorial;
	private Double taxaPorcentagem;
	private Double total;
	
	public void calculoPotencia() {
		informeExpoenteEBase();
		
		Double resultado = 1.0;
		 for(int i = 1; i <= getNumeroExpoente(); i++) {
			 resultado *= getNumeroBase();
		 }
		 if ((getNumeroBase()<0)||(getNumeroExpoente()<0)) {
			 menuCalculadora();
		 }
		 System.out.println(getNumeroBase() + " ^ " + getNumeroExpoente() + " = " + resultado);
		}
	
	public void calcularPorcentagem() {		
		informeValorETaxa();
		Double resultado =  getTotal() * (getTaxaPorcentagem()/100);
		System.out.println(getTaxaPorcentagem() +"% de " +getTotal() +" = "+resultado);
	}
	
	public void calcularFatorial() {
		numeroCalculaFatorial();
		Double numero = getNumeroFatorial();
	    if (numero < 0) {
	        throw new IllegalArgumentException("Números negativos não são aceitos.");
	    }
	    Double fatorial = 1.0;

	    for (Double i = numero; i >= 1; i--) {
	        fatorial *= i;
	    }
	    
	    if(numero == 0) {
	    	System.out.println("Calculando o fatorial de "+numero+"!");
	    	System.out.println("Fatorial de 0! = 1.0");
	    } else {
	    	System.out.println("Fatorial de "+numero+"!"+" = "+fatorial);
	    }
	}

	
	public void decrementarPorcentagem() {
		informeValorETaxa();
		Double resultado = getTotal() * (1 - (getTaxaPorcentagem()/100));
		System.out.println(getTotal()+" - " + getTaxaPorcentagem()+"% de juros = "+resultado);
	}
	
	public void identificarParOuImpar() {
		System.out.print("Informe o número: ");
		Double numero = validarNumero(entrada.nextDouble());
	    if (numero % 2 == 0) {
	    	System.out.println(numero+" é um número par");
	    } else {
	    	System.out.println(numero+" é um número ímpar");
	    }
	}

	
	public void informeValorETaxa() {
		System.out.print("Informe o Valor Total:");
		setTotal(validarNumero(entrada.nextDouble()));
		System.out.print("Informe a taxa porcentagem:");
		setTaxaPorcentagem(validarNumero(entrada.nextDouble()));
		
	}
	
	public void acrescimoPorcentagem() {
		informeValorETaxa();
		Double resultado = getTotal() * (1 + (getTaxaPorcentagem()/100));
		System.out.println(getTotal() +" + "+ getTaxaPorcentagem()+"% de juros = "+resultado);
		
	}
	
	public void informeExpoenteEBase() {
		System.out.print("Informe a base: ");
		setNumeroBase(validarNumero(entrada.nextDouble()));
		
		System.out.print("Informe o expoente: ");
		setNumeroExpoente(validarNumero(entrada.nextDouble()));
	}
	
	public double validarNumero(double numero) {
		double numeroValidado;
		if(numero < 0) {
			System.out.println("Numeros negativos não são aceitos!");
		}
		
		numeroValidado = numero;
		return numeroValidado;
		
	}
	
	public void numeroCalculaFatorial() {
		System.out.print("Informe o numero do fatorial:" );
		setNumeroFatorial(validarNumero(entrada.nextDouble()));
	}

	
	public void menuCalculadora() {
		System.out.println("*******MENU CALCULADORA****************");
		System.out.println("* 1 - Cálculo Potência                *");
		System.out.println("* 2 - Cálculo Fatorial                *");
		System.out.println("* 3 - Cálculo Porcentagem             *");
		System.out.println("* 4 - Cálculo Acrécimo de %           *");
		System.out.println("* 5 - Cálculo Desconto de %           *");
		System.out.println("* 6 - Identifica Par/Ímpar            *");
		System.out.println("* 7 - Sair do Sistema                 *");
		System.out.println("***************************************");
		escolherOpcao();
	}
	
	public void escolherOpcao() {
		System.out.print("Digite a Opção Desejada: ");
		int opcao = entrada.nextInt();	
			switch (opcao) {
			case 1:
				calculoPotencia();
				menuCalculadora();
				break;
			case 2:
				calcularFatorial();
				menuCalculadora();
				break;
			case 3:
				calcularPorcentagem();
				menuCalculadora();
				break;
			case 4:
				acrescimoPorcentagem();
				menuCalculadora();
				break;
			case 5:
				decrementarPorcentagem();
				menuCalculadora();
				break;
			case 6:
				identificarParOuImpar();
				break;
			case 7:
				System.out.println("SISTEMA ENCERRADO!");
				System.exit(0);
				break;
			default:
				System.out.println("Opção Inválida!");
				menuCalculadora();
				break;
			}
	}

	public Double getNumeroExpoente() {
		return numeroExpoente;
	}

	public void setNumeroExpoente(Double numeroExpoente) {
		this.numeroExpoente = numeroExpoente;
	}

	public Double getNumeroBase() {
		return numeroBase;
	}

	public void setNumeroBase(Double numeroBase) {
		this.numeroBase = numeroBase;
	}

	public Double getNumeroFatorial() {
		return numeroFatorial;
	}

	public void setNumeroFatorial(Double numeroFatorial) {
		this.numeroFatorial = numeroFatorial;
	}

	public Double getTaxaPorcentagem() {
		return taxaPorcentagem;
	}

	public void setTaxaPorcentagem(Double taxaPorcentagem) {
		this.taxaPorcentagem = taxaPorcentagem;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}
	
	
	
	
	
	
	
	
}
