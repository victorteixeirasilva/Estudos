package dio.springwebsecurityconfigureadapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebSecurityConfigureAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
