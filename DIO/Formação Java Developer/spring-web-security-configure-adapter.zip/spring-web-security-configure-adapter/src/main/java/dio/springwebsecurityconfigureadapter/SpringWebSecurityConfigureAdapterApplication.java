package dio.springwebsecurityconfigureadapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebSecurityConfigureAdapterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebSecurityConfigureAdapterApplication.class, args);
	}

}
