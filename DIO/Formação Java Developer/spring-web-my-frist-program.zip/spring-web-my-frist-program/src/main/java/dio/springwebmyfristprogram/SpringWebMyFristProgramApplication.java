package dio.springwebmyfristprogram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebMyFristProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebMyFristProgramApplication.class, args);
	}

}
