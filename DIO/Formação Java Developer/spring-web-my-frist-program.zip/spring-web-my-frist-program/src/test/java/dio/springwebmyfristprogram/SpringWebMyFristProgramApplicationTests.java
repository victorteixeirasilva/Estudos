package dio.springwebmyfristprogram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebMyFristProgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
