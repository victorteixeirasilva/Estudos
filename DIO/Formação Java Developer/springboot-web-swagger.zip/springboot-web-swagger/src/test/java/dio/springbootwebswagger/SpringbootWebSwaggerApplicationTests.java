package dio.springbootwebswagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebSwaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
