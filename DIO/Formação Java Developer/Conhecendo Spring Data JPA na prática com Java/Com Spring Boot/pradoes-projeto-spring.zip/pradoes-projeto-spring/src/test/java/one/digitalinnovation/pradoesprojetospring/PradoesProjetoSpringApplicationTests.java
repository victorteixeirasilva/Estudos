package one.digitalinnovation.pradoesprojetospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PradoesProjetoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
