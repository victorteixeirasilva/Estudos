package one.digitalinnovation.pradoesprojetospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PradoesProjetoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PradoesProjetoSpringApplication.class, args);
	}

}
